const initialState = 0;

const ChangeData = (state = initialState, action) => {
    switch (action.type) {
        case "UPDATEDATA": return {

        }
    }
}